/*
* 私密信息
* 建议使用香港服务器
* 只读权限的配置
* */
let key = 'b6bde6af-2340-4eb6-9e9a-f467ff64f0ea';
let secret = '017E87E16D8116DF4A56E140CA7347F2';
let passphrase = '11asdfghjkl';
let urlHost =  'https://www.okex.me';
let websocekHost='wss://real.okex.me:10442/ws/v3';


module.exports.httpkey = key;
module.exports.httpsecret = secret;
module.exports.passphrase = passphrase;
module.exports.urlHost = urlHost;
module.exports.websocekHost = websocekHost;

