/*
* 私密信息
* 建议使用香港服务器
* 交易权限的配置
* */
let key = '4d39c7d5-47dd-47b9-a4b3-0358dba76520';
let secret = '0EA6D68FF45AB88B37C69789CB2A2915';
let passphrase = '11asdfghjkl';
let urlHost =  'https://www.okex.me';
let websocekHost='wss://real.okex.me:10442/ws/v3';


module.exports.httpkey = key;
module.exports.httpsecret = secret;
module.exports.passphrase = passphrase;
module.exports.urlHost = urlHost;
module.exports.websocekHost = websocekHost;
